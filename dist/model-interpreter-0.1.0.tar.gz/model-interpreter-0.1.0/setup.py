# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['model_interpreter']

package_data = \
{'': ['*']}

install_requires = \
['colorlover>=0.3.0,<0.4.0',
 'comet_ml>=2.0,<3.0',
 'numpy>=1.17,<2.0',
 'pandas>=0.25.0,<0.26.0',
 'plotly>=4.0,<5.0',
 'shap @ git+https://github.com/AndreCNF/shap.git@master',
 'torch>=1.1,<2.0',
 'tqdm>=4.32,<5.0']

setup_kwargs = {
    'name': 'model-interpreter',
    'version': '0.1.0',
    'description': 'An API for intuitive interpretation of machine learning models',
    'long_description': None,
    'author': 'André Ferreira',
    'author_email': 'andrecnf@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
